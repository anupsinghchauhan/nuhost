<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>web hosting - Company Name</title>

<link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600|Raleway:400,700" rel="stylesheet">
<link href="/templates/bredh-moon/css/all.min.css?v=d9d193" rel="stylesheet">
<link href="/templates/bredh-moon/css/main.min.css" rel="stylesheet">
<link href="/templates/bredh-moon/css/custom.css" rel="stylesheet">


<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
  <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<script type="30cf169d406ca525d4eccb40-text/javascript">
    var csrfToken = '9556054f3b5a6e310d92c298e5d894f1927ecd20',
        markdownGuide = 'Керівництво по розмітці',
        locale = 'en',
        saved = 'збережено',
        saving = 'автоматичне збереження',
        whmcsBaseUrl = "",
        requiredText = 'Необхідно',
        recaptchaSiteKey = "";
</script>
<script src="/templates/bredh-moon/js/scripts.min.js?v=d9d193" type="30cf169d406ca525d4eccb40-text/javascript"></script>


<link rel="stylesheet" type="text/css" href="/assets/css/fontawesome-all.min.css" />
<script nonce="5b6c9d76-a5ef-4866-bfd0-d691307459d0">(function(w,d){!function(j,k,l,m){j[l]=j[l]||{};j[l].executed=[];j.zaraz={deferred:[],listeners:[]};j.zaraz.q=[];j.zaraz._f=function(n){return function(){var o=Array.prototype.slice.call(arguments);j.zaraz.q.push({m:n,a:o})}};for(const p of["track","set","debug"])j.zaraz[p]=j.zaraz._f(p);j.zaraz.init=()=>{var q=k.getElementsByTagName(m)[0],r=k.createElement(m),s=k.getElementsByTagName("title")[0];s&&(j[l].t=k.getElementsByTagName("title")[0].text);j[l].x=Math.random();j[l].w=j.screen.width;j[l].h=j.screen.height;j[l].j=j.innerHeight;j[l].e=j.innerWidth;j[l].l=j.location.href;j[l].r=k.referrer;j[l].k=j.screen.colorDepth;j[l].n=k.characterSet;j[l].o=(new Date).getTimezoneOffset();if(j.dataLayer)for(const w of Object.entries(Object.entries(dataLayer).reduce(((x,y)=>({...x[1],...y[1]})),{})))zaraz.set(w[0],w[1],{scope:"page"});j[l].q=[];for(;j.zaraz.q.length;){const z=j.zaraz.q.shift();j[l].q.push(z)}r.defer=!0;for(const A of[localStorage,sessionStorage])Object.keys(A||{}).filter((C=>C.startsWith("_zaraz_"))).forEach((B=>{try{j[l]["z_"+B.slice(7)]=JSON.parse(A.getItem(B))}catch{j[l]["z_"+B.slice(7)]=A.getItem(B)}}));r.referrerPolicy="origin";r.src="/cdn-cgi/zaraz/s.js?z="+btoa(encodeURIComponent(JSON.stringify(j[l])));q.parentNode.insertBefore(r,q)};["complete","interactive"].includes(k.readyState)?zaraz.init():j.addEventListener("DOMContentLoaded",zaraz.init)}(w,d,"zarazData","script");})(window,document);</script></head>
<body data-phone-cc-input="1">
<div class="preloader">
<div class="preloader-container">
<svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
<circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
<animatetransform attributename="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15" repeatcount="indefinite" begin="0.1" />
</circle>
<circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
<animatetransform attributename="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10" repeatcount="indefinite" begin="0.2" />
</circle>
<circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
<animatetransform attributename="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5" repeatcount="indefinite" begin="0.3" />
</circle>
</svg>
<span>loading</span>
</div>
</div>
<div id="coodiv-header" class="d-flex mx-auto flex-column subpages-header moon-edition">
<div class="bg_overlay_header">
<div id="particles-bg"></div>
<div class="bg-img-header-new-moon">&nbsp;</div>
</div>

<div class="whmcs-top-header-coodiv">
<div class="container">
<ul class="top-header-right-nav">
<li><i class="bredhicon-chat-inv"></i> <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="9be8eeebebf4e9efdbf8f4f4fff2edb5f5feef">[email&#160;protected]</a></li>
</ul>
<ul class="top-nav">
<li>
<a href="#" class="choose-language whmcs-top-header-coodiv-link" data-toggle="popover" id="languageChooser">
<i class="bredhicon-location-inv"></i>
<span>Українська</span>
</a>
<div id="languageChooserContent" class="hidden">
<ul>
<li>
<a href="/web-hosting.php?language=arabic">العربية</a>
</li>
<li>
<a href="/web-hosting.php?language=azerbaijani">Azerbaijani</a>
</li>
<li>
<a href="/web-hosting.php?language=catalan">Català</a>
</li>
<li>
<a href="/web-hosting.php?language=chinese">中文</a>
</li>
<li>
<a href="/web-hosting.php?language=croatian">Hrvatski</a>
</li>
<li>
<a href="/web-hosting.php?language=czech">Čeština</a>
</li>
<li>
<a href="/web-hosting.php?language=danish">Dansk</a>
</li>
<li>
<a href="/web-hosting.php?language=dutch">Nederlands</a>
</li>
<li>
<a href="/web-hosting.php?language=english">English</a>
</li>
<li>
<a href="/web-hosting.php?language=estonian">Estonian</a>
</li>
<li>
<a href="/web-hosting.php?language=farsi">Persian</a>
</li>
<li>
<a href="/web-hosting.php?language=french">Français</a>
</li>
<li>
<a href="/web-hosting.php?language=german">Deutsch</a>
</li>
<li>
<a href="/web-hosting.php?language=hebrew">עברית</a>
</li>
<li>
<a href="/web-hosting.php?language=hungarian">Magyar</a>
</li>
<li>
<a href="/web-hosting.php?language=italian">Italiano</a>
</li>
<li>
<a href="/web-hosting.php?language=macedonian">Macedonian</a>
</li>
<li>
<a href="/web-hosting.php?language=norwegian">Norwegian</a>
</li>
<li>
<a href="/web-hosting.php?language=portuguese-br">Português</a>
</li>
<li>
<a href="/web-hosting.php?language=portuguese-pt">Português</a>
</li>
<li>
<a href="/web-hosting.php?language=romanian">Română</a>
</li>
<li>
<a href="/web-hosting.php?language=russian">Русский</a>
</li>
<li>
<a href="/web-hosting.php?language=spanish">Español</a>
</li>
<li>
<a href="/web-hosting.php?language=swedish">Svenska</a>
</li>
<li>
<a href="/web-hosting.php?language=turkish">Türkçe</a>
</li>
<li>
<a href="/web-hosting.php?language=ukranian">Українська</a>
</li>
</ul>
</div>
</li>
<li>
<a class="whmcs-top-header-coodiv-link" title="Реєстрація" href="/register.php">
<i class="bredhicon-lock-empty"></i>
<span>Реєстрація</span>
</a>
</li>
<li>
<a class="whmcs-top-header-coodiv-link" href="/cart.php?a=view">
<i class="bredhicon-box"></i>
<span>Переглянути кошик</span>
</a>
</li>
</ul>
</div>
</div>
<nav id="coodiv-navbar-header" class="navbar navbar-expand-md fixed-header-layout">
<div class="container main-header-coodiv-s">
<a class="navbar-brand" href="/index.php">
<img class="w-logo" src="/templates/bredh-moon/img/header/logo-w.png" alt="Company Name" />
<img class="b-logo" src="/templates/bredh-moon/img/header/logo.png" alt="Company Name" />
</a>
<button class="navbar-toggle offcanvas-toggle menu-btn-span-bar ml-auto" data-toggle="offcanvas" data-target="#offcanvas-menu-home">
<span></span>
<span></span>
<span></span>
</button>
<div class="coodiv-colpass-menu-header navbar-offcanvas" id="offcanvas-menu-home">
<ul class="nav navbar-nav ml-auto">

<li data-username="Home" class="nav-item">
<a href="/index.php" class="nav-link active">Головна</a>
</li>
<li data-username="store" class="nav-item dropdown">
<a class="nav-link dropdown" href="#" id="pagesdromdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Store <span class="caret"></span></a>
<ul class="dropdown-menu" aria-labelledby="pagesdromdown">
<li><a href="/cart.php">Browse All</a></li>
</ul>
</li>
<li data-username="domains" class="nav-item dropdown">
<a class="nav-link dropdown" href="#" id="pagesdromdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Домени <span class="caret"></span></a>
<ul class="dropdown-menu" aria-labelledby="pagesdromdown">
<li><a href="/clientarea.php?action=domains">Мої Домени</a></li>
<li><a href="/cart.php?a=add&domain=register">Domain Search</a></li>
</ul>
</li>
<li data-username="support" class="nav-item dropdown">
<a class="nav-link dropdown" href="#" id="pagesdromdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Підтримка<span class="caret"></span></a>
<ul class="dropdown-menu" aria-labelledby="pagesdromdown">
<li><a href="/supporttickets.php">Тікети</a></li>
<li><a href="/submitticket.php">Відкрити тікет</a></li>
</ul>
</li>
<li data-username="announcements" class="nav-item">
<a href="/announcements.php" class="nav-link ">Сповіщення</a>
</li>
<li data-username="knowledgebase" class="nav-item">
<a href="/knowledgebase.php" class="nav-link ">База знань</a>
</li>
<li data-username="contact" class="nav-item">
<a href="/contact.php" class="nav-link ">Зв'язок з нами</a>
</li>
<li class="nav-item dropdown">
<a class="nav-link" role="button" id="webhosting-megamenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">Hosting <span class="nav-new-tag">New</span></a>
<div class="dropdown-menu coodiv-dropdown-header web-menu" aria-labelledby="webhosting-megamenu">
<ul class="web-hosting-menu-header">
<li><i class="fas fa-server"></i> <a href="web-hosting.php">shared hosting <span>Lorem ipsum dolor sit amet</span></a></li>
<li><i class="fab fa-squarespace"></i> <a href="dedicated.php">dedicated hosting <span>Lorem ipsum dolor sit amet</span></a></li>
<li><i class="fas fa-gamepad"></i> <a href="games.php">games servers <span>Lorem ipsum dolor sit amet</span></a></li>
<li><i class="fas fa-cloud"></i> <a href="servers.php">cloud servers <span>Lorem ipsum dolor sit amet</span></a></li>
<li><i class="fab fa-cpanel"></i> <a href="cpanel.php">cPanel Resellers <span>Lorem ipsum dolor sit amet</span></a></li>
<li><i class="fab fa-teamspeak"></i> <a href="voice.php">voice servers <span>Lorem ipsum dolor sit amet</span></a></li>
<li><i class="fab fa-wordpress-simple"></i> <a href="wordpress.php">WordPress hosting <span>Lorem ipsum dolor sit amet</span></a></li>
</ul>
</div>
</li>
</ul>
</div>
<ul class="header-user-info-coodiv">
<li class="dropdown">
<a role="button" id="header-login-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">
Вхід
</a> <span>12365-8448</span>

<div class="dropdown-menu coodiv-dropdown-header user-login-dropdown " aria-labelledby="header-login-dropdown">
<form class="user-login-dropdown-form" method="post" action="https://demo.coodiv.net/dologin.php">
<input type="hidden" name="token" value="9556054f3b5a6e310d92c298e5d894f1927ecd20" />
<div class="form-group username">
<input type="email" name="username" id="inputEmail" placeholder="Введіть email" class="form-control" autofocus>
<i class="fas fa-at"></i>
</div>
<div class="form-group password">
<input type="password" name="password" id="inputPassword" class="form-control" placeholder="Пароль" autocomplete="off">
<i class="fas fa-lock"></i>
</div>
<button data-toggle="tooltip" data-placement="left" title="Увійти" class="user-login-dropdown-form-button" type="submit"><i class="fas fa-angle-right"></i></button>
</form>
</div>

</li>
</ul>
</div>
</nav>
<div class="header-height-clone"></div>
<main class="container mb-auto mt-auto main-header-sub-pages-informations">
<div class="header-lined">
<h1>web hosting</h1>
<ol class="breadcrumb">
<li>
<a href="/index.php"> Головна
</a> </li>
<li class="active">
shared hosting
</li>
</ol>
</div>
</main>
<div class="mt-auto"></div>
</div>
<section id="main-body">
<div class="container">
<div class="row">

<div class="col-xs-12 main-content">
<div class="header-lined">
<h1>web hosting</h1>
<ol class="breadcrumb">
<li>
<a href="/index.php"> Головна
</a> </li>
<li class="active">
shared hosting
</li>
</ol>
</div>
</div></div></section>
<style>
#main-body{
display: none;
}
</style>
<section style="background: #fff;" class="padding-100-0-0 position-relative">
<div class="container">
<div class="row justify-content-between">
<div class="col-md-8 row justify-content-center hosting-plan-row">
<div class="col-md-3">
<div class="third-pricing-table side-left blur-plan">
<span class="plan-commins-soon">Coming Soon</span>
<div class="plan-header">
<span class="headline">250GB SSD</span>
<span class="plan-price">$22 <span>/mo</span></span>
<span class="activated-method">Activate in minutes</span>
</div>
<div class="package-body">
<ul>
<li><strong>E3-1270v6</strong> Processor</li>
<li><strong>32768MB</strong> Memory</li>
<li><strong>5000GB</strong> Bandwidth</li>
<li><strong>10GbE</strong> Ethernet</li>
</ul>
</div>
<div class="package-footer">
<a href="#">order now</a>
</div>
</div>
</div>
<div class="col-md-5">
<div class="third-pricing-table">
<div class="plan-header">
<span class="headline">250GB SSD</span>
<span class="plan-price second-pricing-table-price monthly">
<i class="monthly">$78 <span>/mo</span></i>
<i class="yearly">$163 <span>/year</span></i>
</span>
<span class="activated-method">Activate in minutes</span>
</div>
<div class="package-body">
<ul>
<li><strong>E3-1270v6</strong> Processor</li>
<li><strong>8</strong> CPU @ 3.8Ghz</li>
<li><strong>32768MB</strong> Memory</li>
<li><strong>5000GB</strong> Bandwidth</li>
<li><strong>10GbE</strong> Ethernet</li>
</ul>
</div>
<div class="package-footer">
<a href="#">order now</a>
</div>
</div>
</div>
<div class="col-md-3">
<div class="third-pricing-table side-right">
<div class="plan-header">
<span class="headline">250GB SSD</span>
<span class="plan-price second-pricing-table-price monthly">
<i class="monthly">$81 <span>/mo</span></i>
<i class="yearly">$188 <span>/year</span></i>
</span>
<span class="activated-method">Activate in minutes</span>
</div>
<div class="package-body">
<ul>
<li><strong>E3-1270v6</strong> Processor</li>
<li><strong>32768MB</strong> Memory</li>
<li><strong>5000GB</strong> Bandwidth</li>
<li><strong>10GbE</strong> Ethernet</li>
</ul>
</div>
<div class="package-footer">
<a href="#">order now</a>
</div>
</div>
</div>
</div>
<div class="col-md-4 side-text-right-container side-text-plan-hosting">
<h2 class="side-text-right-title f-size25">We are with you ,<br> every step of the way</h2>
<p class="side-text-right-text f-size16">
Whether you are looking for a <b>personal</b> website hosting plan or a <b>business</b> website hosting plan.
</p>
<ul class="web-hosting-options">
<li><i class="fas fa-database"></i> MySQL 5.7</li>
<li><i class="far fa-window-restore"></i> Cpanel</li>
<li><i class="fas fa-microchip"></i> Solid-state drives</li>
<li><i class="fas fa-shield-alt"></i> Root administrator access</li>
<li><i class="far fa-clock"></i> 24/7 Activate in minutes, online 24x7</li>
<li><i class="fab fa-expeditedssl"></i> Free SSL certificate</li>
</ul>
<div id="monthly-yearly-chenge" class="mr-tp-20 custom-change">
<a class="active monthly-price f-size12"> <span class="change-box-text">monthly</span> <span class="change-box"></span></a>
<a class="yearli-price f-size12"> <span class="change-box-text">annually</span></a>
</div>
</div>
</div>
</div>
</section>
<section class="section-wth-amwaj">
<div class="bg_overlay_section-amwaj">
<img src="/templates/bredh-moon/img/bg/b_bg_02.jpg" alt="img-bg">
</div>
<div class="container">
<div class="row justify-content-between mr-tp-50">
<div class="col-md-6 side-text-right-container">
<h2 class="side-text-right-title">We are with you ,<br> every step of the way</h2>
<p class="side-text-right-text">
Whether you are looking for a <b>personal</b> website hosting plan or a <b>business</b> website hosting plan, We are the perfect solution for you. Our powerful website hosting services will not only help you achieve your overall website goals, but will also provide you with the confidence you need in knowing that you are partnered with a <a href="#">reliable</a> and <a href="#">secure</a> website hosting platform.
<br>
<br> We are one of the easiest website hosting platforms to use, and remain committed to providing our customers with one of the best hosting solutions on the market.
<p>
</div>
<div class="col-md-5">
<div class="display-on-hover-box-container">
<a href="#tab1" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/quality-badge.svg" alt />
</a>
<a href="#tab2" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/inclined-rocket.svg" alt />
</a>
<a href="#tab3" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/public-speech.svg" alt />
</a>
<a href="#tab4" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/big-light.svg" alt />
</a>
<a href="#tab5" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/big-lifesaver.svg" alt />
</a>
<a href="#tab6" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/headphones-with-thin-mic.svg" alt />
</a>
<a href="#tab7" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/inclined-paper-plane.svg" alt />
</a>
<a href="#tab8" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/big-telephone.svg" alt />
</a>
<div class="display-on-hover-box-content">
<div class="display-on-hover-box-cotent-items">
<div id="tab1" class="tab-content-hover">
<h5>word press hosting</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab2" class="tab-content-hover">
<h5>word press2 hosting</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab3" class="tab-content-hover">
<h5>word press3 hosting</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab4" class="tab-content-hover">
<h5>word press4 hosting</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab5" class="tab-content-hover">
<h5>word press5 hosting</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab6" class="tab-content-hover">
<h5>word press6 hosting</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab7" class="tab-content-hover">
<h5>word press7 hosting</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab8" class="tab-content-hover">
<h5>word press8 hosting</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="padding-100-0">
<div class="container">
<h5 class="title-default-coodiv-two">Simple & Powerful tools<span class="mr-tp-10">high performance 100% Intel CPU and 100% SSD bare metal platform.</span></h5>
<div class="row justify-content-center mr-tp-40">
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-002-plug"></i>
<h5>Stay connected all the time</h5>
</div>
</div>
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-025-router"></i>
<h5>Stay connected all the time</h5>
</div>
</div>
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-043-remote-control"></i>
<h5>No noisy neighbors</h5>
</div>
</div>
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-021-virtual-reality"></i>
<h5>Powerful infrastructure</h5>
</div>
</div>
</div>
<div class="row justify-content-center mr-tp-10">
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-004-battery"></i>
<h5>Many OS combinations</h5>
</div>
</div>
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-032-sata"></i>
<h5>Root administrator access</h5>
</div>
</div>
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-036-air-conditioner"></i>
<h5>No long term contracts</h5>
</div>
</div>
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-049-speaker"></i>
<h5>No noisy neighbors</h5>
</div>
</div>
</div>
</div>
</section>
<section style="background: #fff;" class="padding-100-0 with-top-border">
<div class="container">
<h5 class="title-default-coodiv-two">Frequently asked questions.</h5>
<div class="row justify-content-center mr-tp-40">
<div class="col-md-9">
<div class="accordion" id="frequently-questions">
<div class="questions-box">
<div id="headingOne">
<button class="btn questions-title" type="button" data-toggle="collapse" data-target="#questionone" aria-expanded="true" aria-controls="questionone">
How Can I Order New Host ?
</button>
</div>
<div id="questionone" class="collapse show questions-reponse" aria-labelledby="headingOne" data-parent="#frequently-questions">
Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
</div>
</div>
<div class="questions-box">
<div id="headingtwo">
<button class="btn questions-title collapsed" type="button" data-toggle="collapse" data-target="#questiontwo" aria-expanded="true" aria-controls="questiontwo">
What Is Resellers Hosting ?
</button>
</div>
<div id="questiontwo" class="collapse questions-reponse" aria-labelledby="headingtwo" data-parent="#frequently-questions">
Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
</div>
</div>
<div class="questions-box">
<div id="headingtree">
<button class="btn questions-title collapsed" type="button" data-toggle="collapse" data-target="#questiontree" aria-expanded="true" aria-controls="questiontree">
I Want New Domain Name
</button>
</div>
<div id="questiontree" class="collapse questions-reponse" aria-labelledby="headingtree" data-parent="#frequently-questions">
Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
<div class="clearfix"></div>
</div>
</div>
</section>
<section class="footer-section-banner">
<div class="container">
<div class="row free-trial-footer-banner">
<div class="col-md-8">
<h5 class="free-trial-footer-banner-title">join now and have free month of deluxe hosting</h5>
<p class="free-trial-footer-banner-text">We offers a free month of service for new customers.* Sign up for your trial offer and instantly have deluxe hosting in your account with free domain included.</p>
</div>
<div class="col-md-4 free-trial-footer-links d-flex mx-auto flex-column">
<div class="mb-auto"></div>
<div class="mb-auto">
<a class="sign-btn" href="register.php">sign up</a>
<a class="log-btn" href="login.php">log in</a>
</div>
<div class="mt-auto"></div>
</div>
</div>
</div>
</section>
<section class="footer-section">
<div class="container">
<div class="row">
<div class="col-md-9 quiq-links-footer">
<h5 class="quiq-links-footer-title">Quick Links</h5>
<div class="row">
<ul class="col-md-6 quiq-links-footer-ul">
<li><a href="#">our company announcements</a></li>
<li><a href="#">Knowledgebase</a></li>
<li><a href="#">Downloads</a></li>
<li><a href="#">Network Status</a></li>
<li><a href="#">My Support Tickets</a></li>
<li><a href="#">Register a New Domain</a></li>
<li><a href="#">Transfer New Domain</a></li>
<li><a href="#">Software Products</a></li>
<li><a href="#">Dedicated Hosting</a></li>
</ul>
<ul class="col-md-6 quiq-links-footer-ul">
<li><a href="#">Contact Us</a></li>
<li><a href="#">Network Status</a></li>
<li><a href="#">Forgot Password?</a></li>
<li><a href="#">Create an account with us</a></li>
<li><a href="#">Login to your account</a></li>
<li><a href="#">make a new payment</a></li>
<li><a href="#">Review & Checkout</a></li>
<li><a href="#">client area</a></li>
<li><a href="#">manage your account</a></li>
</ul>
</div>
</div>
<div class="col-md-3">
<h5 class="quiq-links-footer-title">secure and contact</h5>
<p class="secure-img-footer-area">
<img src="/templates/bredh-moon/img/footer/secure.png" alt />
<span>this is for demo reason only</span>
</p>
<div class="footer-contact-method">
<a href="#">
<span>email us :</span>
<b><span class="__cf_email__" data-cfemail="2b585e5b5b44595f6b4844444f425d05454e5f">[email&#160;protected]</span></b>
<i class="fas fa-at"></i>
</a>
<a href="#">
<span>call us :</span>
<b>00123 45 67 89 91</b>
<i class="fas fa-phone"></i>
</a>
</div>
</div>
</div>
<div class="mr-tp-40 row justify-content-between footer-area-under">
<div class="col-md-4">
<a href="#"><img class="footer-logo-blue" src="/templates/bredh-moon/img/header/logo-w-f.png" alt /></a>
<div class="footer-social-icons">
<a href="#"><i class="fab fa-facebook-f"></i></a>
<a href="#"><i class="fab fa-twitter"></i></a>
<a href="#"><i class="fab fa-instagram"></i></a>
<a href="#"><i class="fab fa-youtube"></i></a>
<a href="#"><i class="fab fa-dribbble"></i></a>
<a href="#"><i class="fab fa-google"></i></a>
</div>
</div>
<div class="col-md-4 row col-md-offset-4">
<ul class="col-md-6 under-footer-ullist">
<li><a href="#">about us</a></li>
<li><a href="#">our services</a></li>
</ul>
<ul class="col-md-6 under-footer-ullist text-right">
<li><a href="#">privacy policy</a></li>
<li><a href="#">terms of sevice</a></li>
</ul>
</div>
</div>
<div class="row justify-content-between final-footer-area mr-tp-40">
<div class="final-footer-area-text col-md-6">
Copyright &copy; 2023 Company Name. All Rights Reserved.
</div>
<div class="footer-lang-changer col-md-2 text-right col-md-offset-4">
<div class="lang-changer-drop-up">
<a class="menu-btn-changer" href="#"><img src="/templates/bredh-moon/img/flags/usa.svg" alt /> united states</a>
</div>
</div>
</div>
</div>
</section>
<div id="fullpage-overlay" class="hidden">
<div class="outer-wrapper">
<div class="inner-wrapper">
<img src="/assets/img/overlay-spinner.svg">
<br>
<span class="msg"></span>
</div>
</div>
</div>
<div class="modal system-modal fade" id="modalAjax" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content panel-primary">
<div class="modal-header panel-heading">
<button type="button" class="close" data-dismiss="modal">
<span aria-hidden="true">&times;</span>
<span class="sr-only">Close</span>
</button>
<h4 class="modal-title"></h4>
</div>
<div class="modal-body panel-body">
Завантаження...
</div>
<div class="modal-footer panel-footer">
<div class="pull-left loader">
<i class="fas fa-circle-notch fa-spin"></i>
Завантаження...
</div>
<button type="button" class="btn btn-default" data-dismiss="modal">
Close
</button>
<button type="button" class="btn btn-primary modal-submit">
Submit
</button>
</div>
</div>
</div>
</div>
<form action="#" id="frmGeneratePassword" class="form-horizontal">
<div class="modal fade" id="modalGeneratePassword">
<div class="modal-dialog">
<div class="modal-content panel-primary">
<div class="modal-header panel-heading">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<h4 class="modal-title">
Generate Password
</h4>
</div>
<div class="modal-body">
<div class="alert alert-danger hidden" id="generatePwLengthError">
Please enter a number between 8 and 64 for the password length
</div>
<div class="form-group">
<label for="generatePwLength" class="col-sm-4 control-label">Password Length</label>
<div class="col-sm-8">
<input type="number" min="8" max="64" value="12" step="1" class="form-control input-inline input-inline-100" id="inputGeneratePasswordLength">
</div>
</div>
<div class="form-group">
<label for="generatePwOutput" class="col-sm-4 control-label">Generated Password</label>
<div class="col-sm-8">
<input type="text" class="form-control" id="inputGeneratePasswordOutput">
</div>
</div>
<div class="row">
<div class="col-sm-8 col-sm-offset-4">
<button type="submit" class="btn btn-default btn-sm">
<i class="fas fa-plus fa-fw"></i>
Generate new password
</button>
<button type="button" class="btn btn-default btn-sm copy-to-clipboard" data-clipboard-target="#inputGeneratePasswordOutput">
<img src="/assets/img/clippy.svg" alt="Copy to clipboard" width="15">
Copy
</button>
</div>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">
Close
</button>
<button type="button" class="btn btn-primary" id="btnGeneratePasswordInsert" data-clipboard-target="#inputGeneratePasswordOutput">
Copy to clipboard and Insert
</button>
</div>
</div>
</div>
</div>
</form>

<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="/templates/bredh-moon/js/template-scripts.js" type="30cf169d406ca525d4eccb40-text/javascript"></script>

<script src="/templates/bredh-moon/js/flickity.pkgd.min.js" type="30cf169d406ca525d4eccb40-text/javascript"></script>

<script src="/templates/bredh-moon/owlcarousel/owl.carousel.min.js" type="30cf169d406ca525d4eccb40-text/javascript"></script>

<script src="/templates/bredh-moon/js/parallax.min.js" type="30cf169d406ca525d4eccb40-text/javascript"></script>

<script src="/templates/bredh-moon/js/mailchamp.js" type="30cf169d406ca525d4eccb40-text/javascript"></script>

<script src="/templates/bredh-moon/js/bootstrap.offcanvas.min.js" type="30cf169d406ca525d4eccb40-text/javascript"></script>

<script src="/templates/bredh-moon/js/jquery.touchSwipe.min.js" type="30cf169d406ca525d4eccb40-text/javascript"></script>

<script src="/templates/bredh-moon/js/particles-code.js" type="30cf169d406ca525d4eccb40-text/javascript"></script>
<script src="/templates/bredh-moon/js/particles.js" type="30cf169d406ca525d4eccb40-text/javascript"></script>
<script src="/templates/bredh-moon/js/smoothscroll.js" type="30cf169d406ca525d4eccb40-text/javascript"></script>
<script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="30cf169d406ca525d4eccb40-|49" defer></script><script>(function(){var js = "window['__CF$cv$params']={r:'7e6381647cdf2efe',m:'oEIhS_GyDScZ9..EphRICpVMhexgt31KSUukzmGfQpA-1689272065-0-AYqjtiMC5ODdlSuNM50/N+sbYpHQ+HzYE/Mv/bMcLJpE'};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='/cdn-cgi/challenge-platform/scripts/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.nonce = '';_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script></body>
</html>
