<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Portal Home - Company Name</title>

<link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600|Raleway:400,700" rel="stylesheet">
<link href="/templates/bredh-moon/css/all.min.css?v=d9d193" rel="stylesheet">
<link href="/templates/bredh-moon/css/main.min.css" rel="stylesheet">
<link href="/templates/bredh-moon/css/custom.css" rel="stylesheet">


<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
  <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<script type="84f49e25229686b641184b86-text/javascript">
    var csrfToken = '9556054f3b5a6e310d92c298e5d894f1927ecd20',
        markdownGuide = 'Markdown Guide',
        locale = 'en',
        saved = 'saved',
        saving = 'autosaving',
        whmcsBaseUrl = "",
        requiredText = 'Required',
        recaptchaSiteKey = "";
</script>
<script src="/templates/bredh-moon/js/scripts.min.js?v=d9d193" type="84f49e25229686b641184b86-text/javascript"></script>


<link rel="stylesheet" type="text/css" href="/assets/css/fontawesome-all.min.css" />
<script nonce="57eee2c9-9b99-4f6c-86cf-7090086bebc9">(function(w,d){!function(j,k,l,m){j[l]=j[l]||{};j[l].executed=[];j.zaraz={deferred:[],listeners:[]};j.zaraz.q=[];j.zaraz._f=function(n){return function(){var o=Array.prototype.slice.call(arguments);j.zaraz.q.push({m:n,a:o})}};for(const p of["track","set","debug"])j.zaraz[p]=j.zaraz._f(p);j.zaraz.init=()=>{var q=k.getElementsByTagName(m)[0],r=k.createElement(m),s=k.getElementsByTagName("title")[0];s&&(j[l].t=k.getElementsByTagName("title")[0].text);j[l].x=Math.random();j[l].w=j.screen.width;j[l].h=j.screen.height;j[l].j=j.innerHeight;j[l].e=j.innerWidth;j[l].l=j.location.href;j[l].r=k.referrer;j[l].k=j.screen.colorDepth;j[l].n=k.characterSet;j[l].o=(new Date).getTimezoneOffset();if(j.dataLayer)for(const w of Object.entries(Object.entries(dataLayer).reduce(((x,y)=>({...x[1],...y[1]})),{})))zaraz.set(w[0],w[1],{scope:"page"});j[l].q=[];for(;j.zaraz.q.length;){const z=j.zaraz.q.shift();j[l].q.push(z)}r.defer=!0;for(const A of[localStorage,sessionStorage])Object.keys(A||{}).filter((C=>C.startsWith("_zaraz_"))).forEach((B=>{try{j[l]["z_"+B.slice(7)]=JSON.parse(A.getItem(B))}catch{j[l]["z_"+B.slice(7)]=A.getItem(B)}}));r.referrerPolicy="origin";r.src="/cdn-cgi/zaraz/s.js?z="+btoa(encodeURIComponent(JSON.stringify(j[l])));q.parentNode.insertBefore(r,q)};["complete","interactive"].includes(k.readyState)?zaraz.init():j.addEventListener("DOMContentLoaded",zaraz.init)}(w,d,"zarazData","script");})(window,document);</script></head>
<body data-phone-cc-input="1">
<div class="preloader">
<div class="preloader-container">
<svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
<circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
<animatetransform attributename="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15" repeatcount="indefinite" begin="0.1" />
</circle>
<circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
<animatetransform attributename="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10" repeatcount="indefinite" begin="0.2" />
</circle>
<circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
<animatetransform attributename="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5" repeatcount="indefinite" begin="0.3" />
</circle>
</svg>
<span>loading</span>
</div>
</div>
<div id="coodiv-header" class="d-flex mx-auto flex-column  moon-edition">
<div class="bg_overlay_header">
<div id="particles-bg"></div>
<div class="bg-img-header-new-moon">&nbsp;</div>
<span class="header-shapes shape-01"></span>
<span class="header-shapes shape-02"></span>
<span class="header-shapes shape-03"></span>
</div>

<div class="whmcs-top-header-coodiv">
<div class="container">
<ul class="top-header-right-nav">
<li><i class="bredhicon-chat-inv"></i> <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="6e1d1b1e1e011c1a2e0d01010a071840000b1a">[email&#160;protected]</a></li>
</ul>
<ul class="top-nav">
<li>
<a href="#" class="choose-language whmcs-top-header-coodiv-link" data-toggle="popover" id="languageChooser">
<i class="bredhicon-location-inv"></i>
<span>English</span>
</a>
<div id="languageChooserContent" class="hidden">
<ul>
<li>
<a href="/index.php?language=arabic">العربية</a>
</li>
<li>
<a href="/index.php?language=azerbaijani">Azerbaijani</a>
</li>
<li>
<a href="/index.php?language=catalan">Català</a>
</li>
<li>
<a href="/index.php?language=chinese">中文</a>
</li>
<li>
<a href="/index.php?language=croatian">Hrvatski</a>
</li>
<li>
<a href="/index.php?language=czech">Čeština</a>
</li>
<li>
<a href="/index.php?language=danish">Dansk</a>
</li>
<li>
<a href="/index.php?language=dutch">Nederlands</a>
</li>
<li>
<a href="/index.php?language=english">English</a>
</li>
<li>
<a href="/index.php?language=estonian">Estonian</a>
</li>
<li>
<a href="/index.php?language=farsi">Persian</a>
</li>
<li>
<a href="/index.php?language=french">Français</a>
</li>
<li>
<a href="/index.php?language=german">Deutsch</a>
</li>
<li>
<a href="/index.php?language=hebrew">עברית</a>
</li>
<li>
<a href="/index.php?language=hungarian">Magyar</a>
</li>
<li>
<a href="/index.php?language=italian">Italiano</a>
</li>
<li>
<a href="/index.php?language=macedonian">Macedonian</a>
</li>
<li>
<a href="/index.php?language=norwegian">Norwegian</a>
</li>
<li>
<a href="/index.php?language=portuguese-br">Português</a>
</li>
<li>
<a href="/index.php?language=portuguese-pt">Português</a>
</li>
<li>
<a href="/index.php?language=romanian">Română</a>
</li>
<li>
<a href="/index.php?language=russian">Русский</a>
</li>
<li>
<a href="/index.php?language=spanish">Español</a>
</li>
<li>
<a href="/index.php?language=swedish">Svenska</a>
</li>
<li>
<a href="/index.php?language=turkish">Türkçe</a>
</li>
<li>
<a href="/index.php?language=ukranian">Українська</a>
</li>
</ul>
</div>
</li>
<li>
<a class="whmcs-top-header-coodiv-link" title="Register" href="/register.php">
<i class="bredhicon-lock-empty"></i>
<span>Register</span>
</a>
</li>
<li>
<a class="whmcs-top-header-coodiv-link" href="/cart.php?a=view">
<i class="bredhicon-box"></i>
<span>View Cart</span>
</a>
</li>
</ul>
</div>
</div>
<nav id="coodiv-navbar-header" class="navbar navbar-expand-md fixed-header-layout">
<div class="container main-header-coodiv-s">
<a class="navbar-brand" href="/index.php">
<img class="w-logo" src="/templates/bredh-moon/img/header/logo-w.png" alt="Company Name" />
<img class="b-logo" src="/templates/bredh-moon/img/header/logo.png" alt="Company Name" />
</a>
<button class="navbar-toggle offcanvas-toggle menu-btn-span-bar ml-auto" data-toggle="offcanvas" data-target="#offcanvas-menu-home">
<span></span>
<span></span>
<span></span>
</button>
<div class="coodiv-colpass-menu-header navbar-offcanvas" id="offcanvas-menu-home">
<ul class="nav navbar-nav ml-auto">

<li data-username="Home" class="nav-item">
<a href="/index.php" class="nav-link active">Home</a>
</li>
<li data-username="store" class="nav-item dropdown">
<a class="nav-link dropdown" href="#" id="pagesdromdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Store <span class="caret"></span></a>
<ul class="dropdown-menu" aria-labelledby="pagesdromdown">
<li><a href="/cart.php">Browse All</a></li>
<li><a href="/cart.php?a=add&domain=register">Register a New Domain</a></li>
<li><a href="/cart.php?a=add&domain=transfer">Transfer in a Domain</a></li>
</ul>
</li>
<li data-username="domains" class="nav-item dropdown">
<a class="nav-link dropdown" href="#" id="pagesdromdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Domains <span class="caret"></span></a>
<ul class="dropdown-menu" aria-labelledby="pagesdromdown">
<li><a href="/clientarea.php?action=domains">My Domains</a></li>
<li><a href="/cart.php?a=add&domain=register">Register a New Domain</a></li>
<li><a href="/cart.php?a=add&domain=transfer">Transfer in a Domain</a></li>
<li><a href="/cart.php?a=add&domain=register">Domain Search</a></li>
</ul>
</li>
<li data-username="support" class="nav-item dropdown">
<a class="nav-link dropdown" href="#" id="pagesdromdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Support<span class="caret"></span></a>
<ul class="dropdown-menu" aria-labelledby="pagesdromdown">
<li><a href="/supporttickets.php">Tickets</a></li>
<li><a href="/submitticket.php">Open Ticket</a></li>
</ul>
</li>
<li data-username="announcements" class="nav-item">
<a href="/announcements.php" class="nav-link ">Announcements</a>
</li>
<li data-username="knowledgebase" class="nav-item">
<a href="/knowledgebase.php" class="nav-link ">Knowledgebase</a>
</li>
<li data-username="contact" class="nav-item">
<a href="/contact.php" class="nav-link ">Contact Us</a>
</li>
<li class="nav-item dropdown">
<a class="nav-link" role="button" id="webhosting-megamenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">Hosting <span class="nav-new-tag">New</span></a>
<div class="dropdown-menu coodiv-dropdown-header web-menu" aria-labelledby="webhosting-megamenu">
<ul class="web-hosting-menu-header">
<li><i class="fas fa-server"></i> <a href="web-hosting.php">shared hosting <span>Lorem ipsum dolor sit amet</span></a></li>
<li><i class="fab fa-squarespace"></i> <a href="dedicated.php">dedicated hosting <span>Lorem ipsum dolor sit amet</span></a></li>
<li><i class="fas fa-gamepad"></i> <a href="games.php">games servers <span>Lorem ipsum dolor sit amet</span></a></li>
<li><i class="fas fa-cloud"></i> <a href="servers.php">cloud servers <span>Lorem ipsum dolor sit amet</span></a></li>
<li><i class="fab fa-cpanel"></i> <a href="cpanel.php">cPanel Resellers <span>Lorem ipsum dolor sit amet</span></a></li>
<li><i class="fab fa-teamspeak"></i> <a href="voice.php">voice servers <span>Lorem ipsum dolor sit amet</span></a></li>
<li><i class="fab fa-wordpress-simple"></i> <a href="wordpress.php">WordPress hosting <span>Lorem ipsum dolor sit amet</span></a></li>
</ul>
</div>
</li>
</ul>
</div>
<ul class="header-user-info-coodiv">
<li class="dropdown">
<a role="button" id="header-login-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">
Login
</a> <span>12365-8448</span>

<div class="dropdown-menu coodiv-dropdown-header user-login-dropdown " aria-labelledby="header-login-dropdown">
<form class="user-login-dropdown-form" method="post" action="https://demo.coodiv.net/dologin.php">
<input type="hidden" name="token" value="9556054f3b5a6e310d92c298e5d894f1927ecd20" />
<div class="form-group username">
<input type="email" name="username" id="inputEmail" placeholder="Enter email" class="form-control" autofocus>
<i class="fas fa-at"></i>
</div>
<div class="form-group password">
<input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" autocomplete="off">
<i class="fas fa-lock"></i>
</div>
<button data-toggle="tooltip" data-placement="left" title="Login" class="user-login-dropdown-form-button" type="submit"><i class="fas fa-angle-right"></i></button>
</form>
</div>

</li>
</ul>
</div>
</nav>
<div class="header-height-clone"></div>
<main class="container mb-auto mt-auto">
<div class="carousel carousel-main">
<div class="carousel-cell">
<h3 class="mt-3 main-header-text-title"><span>Begin the search for your perfect domain name...</span>Register Domain</h3>
<div style="margin: 0;" class="row">
<form method="post" action="domainchecker.php" id="domain-search-header" class="col-md-push-2 col-md-8">
<input type="hidden" name="token" value="9556054f3b5a6e310d92c298e5d894f1927ecd20" />
<input type="hidden" name="transfer" />
<i class="fas fa-globe"></i>
<input type="text" placeholder="Find your new domain name" id="btnTransfer" placeholder="eg. example.com" autocapitalize="none" data-toggle="tooltip" data-placement="left" data-trigger="manual" title="Required">
<span class="inline-button-domain-order">
<button data-toggle="tooltip" data-placement="left" title="Transfer" id="transfer-btn" type="submit" name="transfer" value="Transfer"><i class="fas fa-undo"></i></button>
<button data-toggle="tooltip" data-placement="left" title="Search" id="search-btn" type="submit" value="Search"><i class="fas fa-search"></i></button>
</span>
</form>
</div>
<span class="col-md-push-2 col-md-8 domain-search-header-pricetext">Starting at <b>$0.99/Year</b></span>
</div>
</div>
</main>
<div class="mt-auto"></div>
</div>
<section class="white-bg">
<div class="container">
<div class="row justify-content-start futures-version-2">
<div class="col-md-3">
<div class="futures-version-2-box">
<i class="bredhicon-share"></i>
<h5>Buy A Domain</h5>
<p>Below you can configure the domain names in your shopping cart selecting the addon services you would like, providing required information for them and defining the nameservers that they will use.</p>
<div class="text-right">
<a class="more-btn" href="domainchecker.php">Register</a>
</div>
</div>
</div>
<div class="col-md-3">
<div class="futures-version-2-box">
<i class="bredhicon-download-cloud"></i>
<h5>Order Hosting</h5>
<p>By trusting us with your business needs, we promise you a 99.9% uptime on any services we provide, outside of any standard maintenance we may provide.</p>
<div class="text-right">
<a class="more-btn" href="cart.php">Order</a>
</div>
</div>
</div>
<div class="col-md-3">
<div class="futures-version-2-box">
<i class="bredhicon-flash"></i>
<h5>Make Payment</h5>
<p>Below is a summary of the selected invoices and the total due to pay all of them. To submit payment please just choose your desired payment method below and then submit.</p>
<div class="text-right">
<a class="more-btn" href="clientarea.php">Pay Now</a>
</div>
</div>
</div>
<div class="col-md-3">
<div class="futures-version-2-box">
<span class="free-badge"><b></b>Free</span>
<i class="bredhicon-mic"></i>
<h5>Get Support</h5>
<p>Our dedication to customer support reaches across the globe as well. We are here to help you with your hosting in any way possible, and you can reach us via phone, email, or live chat.</p>
<div class="text-right">
<a class="more-btn" href="submitticket.php">Support Tickets</a>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="padding-100-0 position-relative white-bg">
<div class="container">
<h5 class="title-default-coodiv-two">check out awesome plans, and order now <span class="mr-tp-20">chose which package is best for you.</span></h5>
<div class="row justify-content-center">
<div class="col-md-5 col-md-push-4">
<div id="monthly-yearly-chenge" class="mr-tp-40 style-two">
<a class="active monthly-price"> <span class="change-box-text">billed monthly</span> <span class="change-box"></span></a>
<a class="yearli-price"> <span class="change-box-text">billed annually</span></a>
</div>
</div>
</div>
<div class="row justify-content-start second-pricing-table-container mr-tp-30">
<div class="col-md-4">
<div class="second-pricing-table">
<h5 class="second-pricing-table-title">Basic plan <span>mostly for personal using</span></h5>
<span class="second-pricing-table-price monthly">
<i class="monthly">$299.99<small>/mo</small></i>
<i class="yearly">$799.99<small>/year</small></i>
</span>
<ul class="second-pricing-table-body">
<li>2 TB of space</li>
<li>unlimited bandwidth</li>
<li>full backup systems</li>
<li>free domain</li>
<li class="not-chacked">unlimited database</li>
</ul>
<a class="second-pricing-table-button" href="#">next setup</a>
</div>
</div>
<div class="col-md-4">
<div class="second-pricing-table">
<h5 class="second-pricing-table-title">Expert plan <span>mostly for personal using</span></h5>
<span class="second-pricing-table-price monthly">
<i class="monthly">$399.99<small>/mo</small></i>
<i class="yearly">$899.99<small>/year</small></i>
</span>
<ul class="second-pricing-table-body">
<li>2 TB of space</li>
<li>unlimited bandwidth</li>
<li>full backup systems</li>
<li>free domain</li>
<li class="not-chacked">unlimited database</li>
</ul>
<a class="second-pricing-table-button" href="#">next setup</a>
</div>
</div>
<div class="col-md-4">
<div class="second-pricing-table style-2 active">
<h5 class="second-pricing-table-title">Relluxe plan <span>mostly for personal using</span></h5>
<span class="second-pricing-table-price monthly">
<i class="monthly">$499.99<small>/mo</small></i>
<i class="yearly">$999.99<small>/year</small></i>
</span>
<ul class="second-pricing-table-body">
<li>2 TB of space</li>
<li>unlimited bandwidth</li>
<li>full backup systems</li>
<li>free domain</li>
<li>unlimited database</li>
</ul>
<a class="second-pricing-table-button" href="#">next setup</a>
</div>
</div>
</div>
</div>
</section>
<section class="our-pertners white-bg">
<div class="container">
<h2 class="d-none">our pertners</h2>
<div class="owl-carousel pertners-carousel owl-theme">
<div class="item">
<a href="#"> <img src="/templates/bredh-moon/img/pertners/logo1.png" alt /> </a>
</div>
<div class="item">
<a href="#"> <img src="/templates/bredh-moon/img/pertners/logo2.png" alt /> </a>
</div>
<div class="item">
<a href="#"> <img src="/templates/bredh-moon/img/pertners/logo3.png" alt /> </a>
</div>
<div class="item">
<a href="#"> <img src="/templates/bredh-moon/img/pertners/logo4.png" alt /> </a>
</div>
<div class="item">
<a href="#"> <img src="/templates/bredh-moon/img/pertners/logo5.png" alt /> </a>
</div>
<div class="item">
<a href="#"> <img src="/templates/bredh-moon/img/pertners/logo1.png" alt /> </a>
</div>
<div class="item">
<a href="#"> <img src="/templates/bredh-moon/img/pertners/logo2.png" alt /> </a>
</div>
<div class="item">
<a href="#"> <img src="/templates/bredh-moon/img/pertners/logo3.png" alt /> </a>
</div>
<div class="item">
<a href="#"> <img src="/templates/bredh-moon/img/pertners/logo4.png" alt /> </a>
</div>
<div class="item">
<a href="#"> <img src="/templates/bredh-moon/img/pertners/logo5.png" alt /> </a>
</div>
</div>
</div>
</section>
<section class="section-wth-amwaj">
<div class="bg_overlay_section-amwaj">
<img src="/templates/bredh-moon/img/bg/b_bg_02.jpg" alt="img-bg">
</div>
<div class="container">
<div class="row justify-content-between mr-tp-50">
<div class="col-md-6 side-text-right-container">
<h2 class="side-text-right-title">We are with you ,<br> every step of the way</h2>
<p class="side-text-right-text">
Whether you are looking for a <b>personal</b> website hosting plan or a <b>business</b> website hosting plan, We are the perfect solution for you. Our powerful website hosting services will not only help you achieve your overall website goals, but will also provide you with the confidence you need in knowing that you are partnered with a <a href="#">reliable</a> and <a href="#">secure</a> website hosting platform.
<br>
<br> We are one of the easiest website hosting platforms to use, and remain committed to providing our customers with one of the best hosting solutions on the market.
<p>
<a class="side-text-right-button" href="#">start with us now</a>
</div>
<div class="col-md-push-1 col-md-5">
<div class="display-on-hover-box-container">
<a href="#tab1" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/quality-badge.svg" alt />
</a>
<a href="#tab2" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/inclined-rocket.svg" alt />
</a>
<a href="#tab3" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/public-speech.svg" alt />
</a>
<a href="#tab4" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/big-light.svg" alt />
</a>
<a href="#tab5" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/big-lifesaver.svg" alt />
</a>
<a href="#tab6" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/headphones-with-thin-mic.svg" alt />
</a>
<a href="#tab7" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/inclined-paper-plane.svg" alt />
</a>
<a href="#tab8" class="display-on-hover-box-items">
<img src="/templates/bredh-moon/img/svgs/hover-box/big-telephone.svg" alt />
</a>
<div class="display-on-hover-box-content">
<div class="display-on-hover-box-cotent-items">
<div id="tab1" class="tab-content-hover">
<h5>Shared Housing</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab2" class="tab-content-hover">
<h5>Dedicated Housing</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab3" class="tab-content-hover">
<h5>Cloud Hosting</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab4" class="tab-content-hover">
<h5>Domains</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab5" class="tab-content-hover">
<h5>VPS Servers</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab6" class="tab-content-hover">
<h5>Cloud VPS</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab7" class="tab-content-hover">
<h5>Reseller Services</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
<div id="tab8" class="tab-content-hover">
<h5>WordPress Hosting</h5>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet elit. Lorem ipsum dolor sit amet</p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="padding-100-0-50 position-relative white-bg">
<div class="container">
<div class="banner-servers-box">
<div class="counter-placeholder"></div>
<div class="banner-text-left">
<h5>our server is<strong>24% faster</strong></h5>
<p>with under 60 seconds worldwide Deploy!</p>
</div>
<a class="benchmarks-link" href="#">benchmarks</a>
</div>
<div class="row justify-content-left server-tabls-head">
<div class="col-md-2">storage</div>
<div class="col-md-2">cpu</div>
<div class="col-md-2">memory</div>
<div class="col-md-2">bandwidth</div>
<div class="col-md-4">price</div>
</div>
<div class="server-tabls-body">
<div class="row justify-content-left server-tabls-row">
<div class="col-md-2"><span class="server-spects-for-mobile">space</span> <b>120 GB </b>SSD</div>
<div class="col-md-2"><span class="server-spects-for-mobile">cpu</span> <b>16 CPU</b></div>
<div class="col-md-2"><span class="server-spects-for-mobile">ram</span> <b>512 MB</b></div>
<div class="col-md-2"><span class="server-spects-for-mobile">bandwidth</span> <b>0.50 TB</b><span class="span-info-servers">IPv6</span></div>
<div class="col-md-2"><span class="server-spects-for-mobile">price</span> <b>$12</b>/mo</div>
<div class="col-md-2"><a class="server-order-button" href="#">order now</a></div>
</div>
<div class="row justify-content-left server-tabls-row best-one">
<div class="col-md-2"><span class="server-spects-for-mobile">space</span> <b>180 GB </b>SSD</div>
<div class="col-md-2"><span class="server-spects-for-mobile">cpu</span> <b>32 CPU</b></div>
<div class="col-md-2"><span class="server-spects-for-mobile">ram</span> <b>6 GB</b></div>
<div class="col-md-2"><span class="server-spects-for-mobile">bandwidth</span> <b>3 TB</b><span class="span-info-servers">IPv6</span></div>
<div class="col-md-2"><span class="server-spects-for-mobile">price</span> <b>$36</b>/mo</div>
<div class="col-md-2"><a class="server-order-button" href="#">order now</a></div>
</div>
<div class="row justify-content-left server-tabls-row">
<div class="col-md-2"><span class="server-spects-for-mobile">space</span> <b>320 GB </b>SSD</div>
<div class="col-md-2"><span class="server-spects-for-mobile">cpu</span> <b>64 CPU</b></div>
<div class="col-md-2"><span class="server-spects-for-mobile">ram</span> <b>12 GB</b></div>
<div class="col-md-2"><span class="server-spects-for-mobile">bandwidth</span> <b>8 TB</b><span class="span-info-servers">IPv6</span></div>
<div class="col-md-2"><span class="server-spects-for-mobile">price</span> <b>$46</b>/mo</div>
<div class="col-md-2"><a class="server-order-button" href="#">order now</a></div>
</div>
</div>
<div class="button-row text-center">
<a class="btn jango-color-btn" href="#">create new account now</a>
</div>
</div>
</section>
<section class="padding-60-0-100 white-bg">
<div class="container">
<h5 class="title-default-coodiv-two">Simple & Powerful tools<span class="mr-tp-10">high performance 100% Intel CPU and 100% SSD bare metal platform.</span></h5>
<div class="row justify-content-center mr-tp-40">
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-002-plug"></i>
<h5>Stay connected all the time</h5>
</div>
</div>
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-025-router"></i>
<h5>Stay connected all the time</h5>
</div>
</div>
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-043-remote-control"></i>
<h5>No noisy neighbors</h5>
</div>
</div>
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-021-virtual-reality"></i>
<h5>Powerful infrastructure</h5>
</div>
</div>
</div>
<div class="row justify-content-center mr-tp-10">
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-004-battery"></i>
<h5>Many OS combinations</h5>
</div>
</div>
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-032-sata"></i>
<h5>Root administrator access</h5>
</div>
</div>
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-036-air-conditioner"></i>
<h5>No long term contracts</h5>
</div>
</div>
<div class="col-md-3">
<div class="box-features-one">
<i class="e-flaticon-049-speaker"></i>
<h5>No noisy neighbors</h5>
</div>
</div>
</div>
</div>
</section>
<section id="main-body">
<div class="container">
<div class="row">

<div class="col-xs-12 main-content">
<h2 class="homepagetitle">News</h2>
<div class="announcement-single homepage-anouncement">
<h3>
<span class="label label-default">
May 30th
</span>
<a href="/index.php?rp=/announcements/1/Thank-you-for-choosing-WHMCS.html">Thank you for choosing WHMCS!</a>
</h3>
<blockquote>
<p>
Welcome to WHMCS!
You have made a great choice and we want to help you get up and running as
quickly as possible.
This is a sample announcement. Announcements are a great way to keep your
customers informed about news and special offers. You can edit or delete this
announcement by logging into the admin area and navigating to Support &gt;
...
<a href="/index.php?rp=/announcements/1/Thank-you-for-choosing-WHMCS.html" class="label label-warning">Read More &raquo;</a>
</p>
</blockquote>
</div>
</div>
<div class="clearfix"></div>
</div>
</div>
</section>
<section class="footer-section-banner">
<div class="container">
<div class="row free-trial-footer-banner">
<div class="col-md-8">
<h5 class="free-trial-footer-banner-title">join now and have free month of deluxe hosting</h5>
<p class="free-trial-footer-banner-text">We offers a free month of service for new customers.* Sign up for your trial offer and instantly have deluxe hosting in your account with free domain included.</p>
</div>
<div class="col-md-4 free-trial-footer-links d-flex mx-auto flex-column">
<div class="mb-auto"></div>
<div class="mb-auto">
<a class="sign-btn" href="register.php">sign up</a>
<a class="log-btn" href="login.php">log in</a>
</div>
<div class="mt-auto"></div>
</div>
</div>
</div>
</section>
<section class="footer-section">
<div class="container">
<div class="row">
<div class="col-md-9 quiq-links-footer">
<h5 class="quiq-links-footer-title">Quick Links</h5>
<div class="row">
<ul class="col-md-6 quiq-links-footer-ul">
<li><a href="#">our company announcements</a></li>
<li><a href="#">Knowledgebase</a></li>
<li><a href="#">Downloads</a></li>
<li><a href="#">Network Status</a></li>
<li><a href="#">My Support Tickets</a></li>
<li><a href="#">Register a New Domain</a></li>
<li><a href="#">Transfer New Domain</a></li>
<li><a href="#">Software Products</a></li>
<li><a href="#">Dedicated Hosting</a></li>
</ul>
<ul class="col-md-6 quiq-links-footer-ul">
<li><a href="#">Contact Us</a></li>
<li><a href="#">Network Status</a></li>
<li><a href="#">Forgot Password?</a></li>
<li><a href="#">Create an account with us</a></li>
<li><a href="#">Login to your account</a></li>
<li><a href="#">make a new payment</a></li>
<li><a href="#">Review & Checkout</a></li>
<li><a href="#">client area</a></li>
<li><a href="#">manage your account</a></li>
</ul>
</div>
</div>
<div class="col-md-3">
<h5 class="quiq-links-footer-title">secure and contact</h5>
<p class="secure-img-footer-area">
<img src="/templates/bredh-moon/img/footer/secure.png" alt />
<span>this is for demo reason only</span>
</p>
<div class="footer-contact-method">
<a href="#">
<span>email us :</span>
<b><span class="__cf_email__" data-cfemail="ccbfb9bcbca3beb88cafa3a3a8a5bae2a2a9b8">[email&#160;protected]</span></b>
<i class="fas fa-at"></i>
</a>
<a href="#">
<span>call us :</span>
<b>00123 45 67 89 91</b>
<i class="fas fa-phone"></i>
</a>
</div>
</div>
</div>
<div class="mr-tp-40 row justify-content-between footer-area-under">
<div class="col-md-4">
<a href="#"><img class="footer-logo-blue" src="/templates/bredh-moon/img/header/logo-w-f.png" alt /></a>
<div class="footer-social-icons">
<a href="#"><i class="fab fa-facebook-f"></i></a>
<a href="#"><i class="fab fa-twitter"></i></a>
<a href="#"><i class="fab fa-instagram"></i></a>
<a href="#"><i class="fab fa-youtube"></i></a>
<a href="#"><i class="fab fa-dribbble"></i></a>
<a href="#"><i class="fab fa-google"></i></a>
</div>
</div>
<div class="col-md-4 row col-md-offset-4">
<ul class="col-md-6 under-footer-ullist">
<li><a href="#">about us</a></li>
<li><a href="#">our services</a></li>
</ul>
<ul class="col-md-6 under-footer-ullist text-right">
<li><a href="#">privacy policy</a></li>
<li><a href="#">terms of sevice</a></li>
</ul>
</div>
</div>
<div class="row justify-content-between final-footer-area mr-tp-40">
<div class="final-footer-area-text col-md-6">
Copyright &copy; 2023 Company Name. All Rights Reserved.
</div>
<div class="footer-lang-changer col-md-2 text-right col-md-offset-4">
<div class="lang-changer-drop-up">
<a class="menu-btn-changer" href="#"><img src="/templates/bredh-moon/img/flags/usa.svg" alt /> united states</a>
</div>
</div>
</div>
</div>
</section>
<div id="fullpage-overlay" class="hidden">
<div class="outer-wrapper">
<div class="inner-wrapper">
<img src="/assets/img/overlay-spinner.svg">
<br>
<span class="msg"></span>
</div>
</div>
</div>
<div class="modal system-modal fade" id="modalAjax" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content panel-primary">
<div class="modal-header panel-heading">
<button type="button" class="close" data-dismiss="modal">
<span aria-hidden="true">&times;</span>
<span class="sr-only">Close</span>
</button>
<h4 class="modal-title"></h4>
</div>
<div class="modal-body panel-body">
Loading...
</div>
<div class="modal-footer panel-footer">
<div class="pull-left loader">
<i class="fas fa-circle-notch fa-spin"></i>
Loading...
</div>
<button type="button" class="btn btn-default" data-dismiss="modal">
Close
</button>
<button type="button" class="btn btn-primary modal-submit">
Submit
</button>
</div>
</div>
</div>
</div>
<form action="#" id="frmGeneratePassword" class="form-horizontal">
<div class="modal fade" id="modalGeneratePassword">
<div class="modal-dialog">
<div class="modal-content panel-primary">
<div class="modal-header panel-heading">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<h4 class="modal-title">
Generate Password
</h4>
</div>
<div class="modal-body">
<div class="alert alert-danger hidden" id="generatePwLengthError">
Please enter a number between 8 and 64 for the password length
</div>
<div class="form-group">
<label for="generatePwLength" class="col-sm-4 control-label">Password Length</label>
<div class="col-sm-8">
<input type="number" min="8" max="64" value="12" step="1" class="form-control input-inline input-inline-100" id="inputGeneratePasswordLength">
</div>
</div>
<div class="form-group">
<label for="generatePwOutput" class="col-sm-4 control-label">Generated Password</label>
<div class="col-sm-8">
<input type="text" class="form-control" id="inputGeneratePasswordOutput">
</div>
</div>
<div class="row">
<div class="col-sm-8 col-sm-offset-4">
<button type="submit" class="btn btn-default btn-sm">
<i class="fas fa-plus fa-fw"></i>
Generate new password
</button>
<button type="button" class="btn btn-default btn-sm copy-to-clipboard" data-clipboard-target="#inputGeneratePasswordOutput">
<img src="/assets/img/clippy.svg" alt="Copy to clipboard" width="15">
Copy
</button>
</div>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">
Close
</button>
<button type="button" class="btn btn-primary" id="btnGeneratePasswordInsert" data-clipboard-target="#inputGeneratePasswordOutput">
Copy to clipboard and Insert
</button>
</div>
</div>
</div>
</div>
</form>

<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="/templates/bredh-moon/js/template-scripts.js" type="84f49e25229686b641184b86-text/javascript"></script>

<script src="/templates/bredh-moon/js/flickity.pkgd.min.js" type="84f49e25229686b641184b86-text/javascript"></script>

<script src="/templates/bredh-moon/owlcarousel/owl.carousel.min.js" type="84f49e25229686b641184b86-text/javascript"></script>

<script src="/templates/bredh-moon/js/parallax.min.js" type="84f49e25229686b641184b86-text/javascript"></script>

<script src="/templates/bredh-moon/js/mailchamp.js" type="84f49e25229686b641184b86-text/javascript"></script>

<script src="/templates/bredh-moon/js/bootstrap.offcanvas.min.js" type="84f49e25229686b641184b86-text/javascript"></script>

<script src="/templates/bredh-moon/js/jquery.touchSwipe.min.js" type="84f49e25229686b641184b86-text/javascript"></script>

<script src="/templates/bredh-moon/js/particles-code.js" type="84f49e25229686b641184b86-text/javascript"></script>
<script src="/templates/bredh-moon/js/particles.js" type="84f49e25229686b641184b86-text/javascript"></script>
<script src="/templates/bredh-moon/js/smoothscroll.js" type="84f49e25229686b641184b86-text/javascript"></script>
<script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="84f49e25229686b641184b86-|49" defer></script><script>(function(){var js = "window['__CF$cv$params']={r:'7e63802e9a667cbc',m:'k5RasBgo9VDPi48_35XsZhZT8Ix_D.Us_BEwigdmc9U-1689272015-0-ARAlTOLt6Z9R9jpLpoqBKhN9LfvsNq3QqIHnvxKoVFvD'};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='/cdn-cgi/challenge-platform/scripts/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.nonce = '';_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script></body>
</html>
